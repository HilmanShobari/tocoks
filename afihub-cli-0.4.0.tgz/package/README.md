# Afihub installer 0.4.0

## Connect: pemasangan otomatis sampai siap uji sandbox

Untuk frontend Vite/React atau Vite/Vue dan backend Node.js SQLite Checkout/outbox yang dikenali (pola Pendar Beauty). Connect memerlukan Node.js >=22.13. SDK browser/Node yang dibawa tetap 0.2.0; paket belum dipublikasikan ke npm registry.

1. Unduh afihub-cli-0.4.0.tgz dan konfigurasi privat afihub.connect.json dari Brand Portal, simpan di root proyek brand.
2. Jalankan:

```sh
npm install --ignore-scripts --include=dev --save-dev --save-exact ./afihub-cli-0.4.0.tgz
npx --no-install afihub help
npx --no-install afihub connect --connection ./afihub.connect.json
```

3. Jalankan setiap baris berurutan. Pastikan help menampilkan installer 0.4.0 sebelum connect. SDK browser/Node.js dan CLI adalah paket berbeda; SDK yang terpasang belum berarti CLI tersedia. Terima saran pemindaian yang cocok, periksa daftar file, lalu konfirmasi.
4. Connect menulis env/tracking, memasang SDK dan adapter pembayaran, menyimpan backup, menjalankan build serta pemeriksaan offline.
5. Jalankan afihub doctor, restart layanan sendiri, lalu uji pembayaran sandbox melalui link kreator. Periksa Konversi dan komisi Afihub. Tidak ada copas kode pembayaran untuk adapter yang didukung.

Connect tidak menjalankan/menghentikan layanan, menyentuh database order nyata, atau membuat pembayaran/komisi nyata. Verifikasi memakai database :memory: dan transport gateway tiruan dalam child process. Global fetch pada child diblokir. `local_verified` dan paymentAdapter: true adalah bukti pemasangan/pemeriksaan lokal, bukan pembayaran atau komisi live.

### CLI tidak ditemukan atau npm E404

Jalankan terminal di root website yang berisi package.json. Pastikan installer .tgz ada di folder tersebut, ulangi npm install di atas, lalu periksa bahwa @afihub/cli tercatat di devDependencies dan help berhasil. Paket belum tersedia di npm registry; jangan mengganti pemasangan lokal dengan npm install afihub atau npx afihub. File installer yang masih ada tidak perlu diunduh ulang.

Setelah install berhasil, Windows PowerShell dapat memanggil CLI lokal langsung:

```powershell
.\node_modules\.bin\afihub.cmd help
.\node_modules\.bin\afihub.cmd connect --connection ./afihub.connect.json
.\node_modules\.bin\afihub.cmd doctor
```

Simpan installer .tgz untuk dependency file lokal. Konfigurasi privat afihub.connect.json boleh dihapus setelah connect berhasil; jangan commit atau membagikannya.

## Batas adapter dan perlindungan source

Adapter node-sqlite-checkout-outbox-v1 memeriksa fingerprint seluruh checkout/config/server yang dikenal sebelum patch. Verifikasi provider, harga, token order, origin, transisi status, dan urutan outbox harus cocok. Identitas deployment literal (slug/port/origin), whitespace/comment, dan contoh lama yang salah ditempel dikenali secara terbatas. Kode custom lain ditolak sebelum menulis; gunakan init dan panduan manual jika belum didukung. Tidak menebak gateway.

Perubahan: field afihub_click_id pada order, konfigurasi SDK env pada loader runtime, URL penuh SDK, sender outbox yang menggunakan SDK, error 4xx blocked, kesempatan retry setelah restart. Order/item identity lama tetap stabil. Callback gateway dan perhitungan harga tidak diganti. Panggilan eksplisit loader JSON lama tetap kompatibel untuk caller legacy/test; server default tanpa argumen membaca env SDK.

Script build frontend harus vite build (opsional diteruskan ke build backend); backend build hanya node --check. prebuild/postbuild custom ditolak. Npm install SDK memakai --ignore-scripts. Build Vite tetap menjalankan konfigurasi/plugin proyek seperti build biasa. Source adapter diverifikasi kembali sebelum pemeriksaan offline.

Backup berisi env lama: .afihub/backups ignored dan file mode 0600. Ada lock connect untuk mencegah dua pemasangan bersamaan. File yang berubah setelah preview atau adapter yang dikustomisasi ditolak. Build/pemeriksaan gagal memulihkan source, env dan manifest; node_modules dan dist bisa tetap berubah. Edit bersamaan saat rollback memerlukan pemulihan manual dari backup. Jangan bagikan secret/config privat/backup.

```sh
npx --no-install afihub connect --connection ./afihub.connect.json --dry-run
npx --no-install afihub scan
npx --no-install afihub doctor
```

`--yes` menerima rencana tanpa prompt, bukan melewati pemeriksaan kecocokan. `--no-install` hanya untuk dependencies yang sudah terpasang; build/pemeriksaan tetap dijalankan. Connect dapat diulang tanpa membuat order baru.

## Init / pemasangan manual

`afihub init` masih tersedia untuk Vite, Vue, Next App Router atau HTML statis dengan backend Node.js (Node >=20). Init memasang tracking/helper, tidak menghubungkan pembayaran otomatis. PHP/Python/Go memakai panduan API manual; Shopify/WooCommerce tidak berubah. Lihat panduan lengkap Website Custom di Brand Portal.

Saran checkout memerlukan satu kecocokan POST frontend/backend; ambiguous/dynamic/external/mode env berbeda tidak mendapat default tebakan. Scanner tidak mengeksekusi source. Batas 600 file, kedalaman 7, 256 KiB/file; dependencies, vendor, generated Afihub, tests/docs/data dan symlink diabaikan. Secret tidak ditampilkan; input secret interaktif disembunyikan. Konfigurasi privat dengan UTF8 BOM diterima; file hilang dilaporkan secara khusus. Semua folder/file harus berada di proyek brand; symlink keluar ditolak.
