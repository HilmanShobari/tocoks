import {readFile,writeFile,mkdir,unlink,stat} from 'node:fs/promises';
import {join,dirname,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {planSetup,applySetup,readText,safePath} from './installer.mjs';
import {patchOutbox,validateConnected,digest,adapterID} from './adapters/outbox.mjs';

const names=['checkout','config','server'];
const packageRoot=dirname(fileURLToPath(import.meta.url));
const posix=value=>value.replaceAll('\\','/');
function npmCli(){return process.env.AFIHUB_NPM_CLI||process.env.npm_execpath||join(dirname(process.execPath),'node_modules/npm/bin/npm-cli.js');}
function buildCommands(rootPkg,backendPkg,backendName) {
  if([rootPkg,backendPkg].some(pkg=>pkg.scripts?.prebuild||pkg.scripts?.postbuild))throw new Error('Hook build khusus tidak didukung adapter otomatis.');
  const front=rootPkg.scripts?.build||'';
  const allowedFront=['vite build','vite build && npm --prefix '+backendName+' run build'];
  if(!allowedFront.includes(front))throw new Error('Adapter memerlukan build Vite yang dikenali. Script build khusus harus diperiksa manual; tidak ada file diubah.');
  const back=backendPkg.scripts?.build||'';
  if(!back||!back.split(/\s*&&\s*/).every(command=>/^node --check [A-Za-z0-9_./-]+\.[cm]?js$/.test(command)))throw new Error('Script build backend tidak dikenali. Tidak ada file diubah.');
  return {frontend:front,backend:back};
}
export async function planConnect(options) {
  const [major,minor]=process.versions.node.split('.').map(Number);
  if(major<22||major===22&&minor<13)throw new Error('Adapter SQLite memerlukan Node.js >=22.13.');
  const plan=await planSetup(options);
  if(!['vite','vue'].includes(plan.framework))throw new Error('Adapter otomatis awal mendukung Vite + Node SQLite outbox. Gunakan init/panduan manual untuk backend lain.');
  const sources={},paths={};
  for(const name of names){paths[name]=await safePath(plan.root,join(plan.backend,name+'.mjs'));sources[name]=await readText(paths[name]);if(!sources[name])throw new Error('Adapter membutuhkan '+name+'.mjs pada backend.');}
  const previous=JSON.parse(await readText(join(plan.root,'afihub.setup.json'))||'{}');
  let patch;
  if(previous.adapter?.id===adapterID) {
    if(!validateConnected(sources,previous.adapter.fingerprints))throw new Error('Kode adapter telah dimodifikasi. Installer tidak menimpa perubahan Anda.');
    patch={id:adapterID,changes:sources,fingerprints:previous.adapter.fingerprints};
  } else patch=patchOutbox(sources);
  const frontendPkg=JSON.parse(await readText(join(plan.root,'package.json')));
  const backendPkg=JSON.parse(await readText(join(plan.backend,'package.json')));
  const builds=buildCommands(frontendPkg,backendPkg,plan.report.backend);
  for(const name of names) {
    execFileSync(process.execPath,['--check','--input-type=module'],{input:patch.changes[name],stdio:['pipe','pipe','pipe']});
    plan.writes.set(paths[name],patch.changes[name]);
  }
  plan.report.paymentHook='connected_adapter';
  plan.report.verification='local_checks_pending';
  plan.report.adapter={id:patch.id,fingerprints:patch.fingerprints,builds};
  plan.report.instructions=['Restart frontend/backend sendiri agar konfigurasi baru terbaca.', 'Uji pembayaran sandbox melalui link kreator; periksa Konversi dan komisi di Afihub. Pemeriksaan lokal bukan bukti komisi nyata.'];
  plan.writes.set(join(plan.root,'afihub.setup.json'),JSON.stringify(plan.report,null,2)+'\n');
  plan.originals=new Map();for(const path of [...plan.writes.keys(),join(plan.root,'package.json'),join(plan.backend,'package.json')])plan.originals.set(path,await readText(path));
  return plan;
}
export async function applyConnect(plan,{install=true}={}) {
  const snapshots=new Map();
  for(const [path,content] of plan.originals)snapshots.set(path,{content,exists:await stat(path).then(()=>true,e=>{if(e.code==='ENOENT')return false;throw e;})});
  for(const cwd of new Set([plan.root,plan.backend]))for(const name of ['package.json','package-lock.json']){const path=join(cwd,name);snapshots.set(path,{content:await readText(path),exists:await stat(path).then(()=>true,e=>{if(e.code==='ENOENT')return false;throw e;})});}
  const lockPath=await safePath(plan.root,'.afihub/connect.lock');await mkdir(dirname(lockPath),{recursive:true});
  try {await writeFile(lockPath,String(process.pid),{flag:'wx',mode:0o600});}catch(e){if(e.code==='EEXIST')throw new Error('Connect lain sedang berjalan atau lock tersisa. Periksa .afihub/connect.lock sebelum mencoba lagi.');throw e;}
  let applied=false;
  try {
    for(const [path,original] of plan.originals)if(await readText(path)!==original)throw new Error('File berubah setelah preview. Ulangi connect; tidak ada file ditimpa.');
    const result=await applySetup(plan,{install,onWritten:()=>{applied=true;}});
    const currentBuilds=buildCommands(JSON.parse(await readText(join(plan.root,'package.json'))),JSON.parse(await readText(join(plan.backend,'package.json'))),plan.report.backend);
    if(JSON.stringify(currentBuilds)!==JSON.stringify(plan.report.adapter.builds))throw new Error('Script build berubah selama pemasangan.');
    const targets=[[plan.root,'frontend']];
    if(currentBuilds.frontend!=='vite build && npm --prefix '+plan.report.backend+' run build')targets.push([plan.backend,'backend']);
    for(const [cwd,name] of targets) {
      console.log('Memeriksa build '+name+'...');
      execFileSync(process.execPath,[npmCli(),'run','build'],{cwd,stdio:'inherit'});
    }
    const verificationFile=await safePath(plan.root,'.afihub/adapter-check.json');
    await writeFile(verificationFile,JSON.stringify(plan.report.adapter.fingerprints),{mode:0o600});
    const output=execFileSync(process.execPath,[join(packageRoot,'verify-adapter.mjs'),plan.backend,verificationFile],{encoding:'utf8',stdio:['ignore','pipe','pipe']});
    const verification=JSON.parse(output);
    plan.report.verification='local_verified';plan.report.adapter.checks=verification;
    await writeFile(join(plan.root,'afihub.setup.json'),JSON.stringify(plan.report,null,2)+'\n');
    return {...result,verification};
  } catch(error) {
    if(applied) {
      // Restore source/config/manifest files. Installed node_modules and build artifacts may remain.
      for(const path of plan.writes.keys()) {
        if(await readText(path)!==plan.writes.get(path))throw new Error('Pemeriksaan gagal dan file berubah bersamaan. Backup tersedia di .afihub/backups; pemulihan manual diperlukan.');
      }
      for(const [path,original] of snapshots) {
        if(original.exists)await writeFile(path,original.content);else await unlink(path).catch(e=>{if(e.code!=='ENOENT')throw e;});
      }
      throw new Error('Build/pemeriksaan adapter gagal. Source, env dan manifest dikembalikan; backup tersedia. Dependencies/build artifacts mungkin masih tersisa.');
    }
    throw error;
  } finally {await unlink(lockPath).catch(()=>{});}
}
