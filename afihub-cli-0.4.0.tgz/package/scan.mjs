import {readdir,readFile,stat,realpath} from 'node:fs/promises';
import {resolve,join,relative,isAbsolute} from 'node:path';

const ignored = new Set(['node_modules','vendor','dist','build','coverage','.git','.afihub','test','tests','__tests__','fixtures','docs','data','afihub']);
const sourceFile = /\.(?:[cm]?[jt]sx?|html|vue)$/;
const validPath = value => typeof value === 'string' && /^\/(?!\/)[A-Za-z0-9/_~.%:@+-]+$/.test(value);
const posix = value => value.replaceAll('\\','/');
async function text(path) {try{return await readFile(path,'utf8');}catch(e){if(e.code==='ENOENT')return '';throw e;}}
function envValues(source) {
  const result={};
  for(const line of source.split(/\r?\n/)) {
    const match=line.match(/^\s*((?:VITE_|NEXT_PUBLIC_)[A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if(!match)continue;
    let value=match[2];
    if(value.startsWith('"')&&value.endsWith('"')) {try{value=JSON.parse(value);}catch{value=value.slice(1,-1);}}
    else if(value.startsWith("'")&&value.endsWith("'"))value=value.slice(1,-1);
    else value=value.replace(/\s+#.*$/,'');
    result[match[1]]=value;
  }
  return result;
}
// Small static lexer, not an evaluator. Comments and strings never become executable code.
function lex(source) {
  const out=[];let i=0,line=1;
  const push=(kind,value,start,startLine)=>out.push({kind,value,start,end:i,line:startLine});
  while(i<source.length) {
    const start=i,startLine=line,c=source[i];
    if(/\s/.test(c)){if(c==='\n')line++;i++;continue;}
    if(source.startsWith('//',i)){while(i<source.length&&source[i]!=='\n')i++;continue;}
    if(source.startsWith('/*',i)){i+=2;while(i<source.length&&!source.startsWith('*/',i)){if(source[i]==='\n')line++;i++;}i+=2;continue;}
    if(['"',"'",'`'].includes(c)) {
      i++;let value='',dynamic=false;
      while(i<source.length&&source[i]!==c){if(source[i]==='\n')line++;if(c==='`'&&source.startsWith('${',i))dynamic=true;if(source[i]==='\\'){i++;const escape=source[i++];value+=({n:'\n',r:'\r',t:'\t'}[escape]??escape);}else value+=source[i++];}
      i++;push(dynamic?'dynamic':'string',value,start,startLine);continue;
    }
    if(/[A-Za-z_$]/.test(c)){i++;while(/[A-Za-z0-9_$]/.test(source[i]||'')&&i<source.length)i++;push('identifier',source.slice(start,i),start,startLine);continue;}
    if(c==='/' && ['=','(','[',',',':','return','||','??'].includes(out.at(-1)?.value)) {
      i++;let cls=false;
      while(i<source.length){if(source[i]==='\\'){i+=2;continue;}if(source[i]==='[')cls=true;if(source[i]===']')cls=false;if(source[i]==='/'&&!cls){i++;break;}if(source[i]==='\n')line++;i++;}
      while(/[a-z]/i.test(source[i]||'')&&i<source.length)i++;push('regex',source.slice(start,i),start,startLine);continue;
    }
    const pair=source.slice(i,i+3)==='==='?'===':['==','&&','||','??','=>','?.'].find(v=>source.startsWith(v,i));
    i+=pair?.length||1;push('punct',pair||c,start,startLine);
  }
  return out;
}
function closing(tokens,start) {
  const pairs={'(':')','[':']','{':'}'};const stack=[];
  for(let i=start;i<tokens.length;i++){const value=tokens[i].value;if(tokens[i].kind==='string'||tokens[i].kind==='dynamic'||tokens[i].kind==='regex')continue;if(pairs[value])stack.push(pairs[value]);else if(value===stack.at(-1)){stack.pop();if(!stack.length)return i;}}
  return -1;
}
function args(tokens,start) {
  const end=closing(tokens,start);if(end<0)return null;
  const result=[];let part=start+1;
  for(let i=part;i<end;i++){if(['(','[','{'].includes(tokens[i].value)){i=closing(tokens,i);if(i<0)return null;}else if(tokens[i].value===','){result.push(tokens.slice(part,i));part=i+1;}}
  result.push(tokens.slice(part,end));return{parts:result,end};
}
function expression(tokens,constants,env) {
  let index=0;
  function atom() {
    const t=tokens[index++];if(!t)return undefined;
    let value;
    if(t.kind==='string')value=t.value;
    else if(t.value==='('){value=choice();if(tokens[index++]?.value!==')')return undefined;}
    else if(t.kind==='identifier') {
      const name=[t.value];while(['.','?.'].includes(tokens[index]?.value)){index++;name.push(tokens[index++]?.value);}
      const full=name.join('.');
      value=['import.meta.env','process.env'].some(prefix=>full.startsWith(prefix+'.')) ? env[name.at(-1)] : constants.get(full);
    }
    // Only the standard trailing slash removal is understood. Other methods stay unresolved.
    if(tokens[index]?.value==='.'&&tokens[index+1]?.value==='replace'){
      const call=args(tokens,index+2);
      if(!call||call.parts[0]?.[0]?.value!=='/\\/$/'||call.parts[1]?.[0]?.value!=='' )return undefined;
      value=typeof value==='string'?value.replace(/\/$/,''):undefined;index=call.end+1;
    }
    return value;
  }
  function sum(){let value=atom();while(tokens[index]?.value==='+'){index++;const other=atom();value=typeof value==='string'&&typeof other==='string'?value+other:undefined;}return value;}
  function choice(){let value=sum();while(['||','??'].includes(tokens[index]?.value)){const op=tokens[index++].value;const other=sum();value=(op==='||'?!value:value==null)?other:value;}return value;}
  const value=choice();return index===tokens.length?value:undefined;
}
function constantsIn(tokens,env) {
  const values=new Map();
  for(let i=0;i<tokens.length;i++)if(tokens[i].value==='const'&&tokens[i+1]?.kind==='identifier'&&tokens[i+2]?.value==='='){
    let end=i+3;while(end<tokens.length&&tokens[end].value!==';')end++;
    const value=expression(tokens.slice(i+3,end),values,env);if(typeof value==='string') { const name=tokens[i+1].value; values.set(name,values.has(name)&&values.get(name)!==value?undefined:value); }
  }
  return values;
}
function topProperties(tokens) {
  if(tokens?.[0]?.value!=='{'||tokens.at(-1)?.value!=='}')return null;
  const props=[];
  for(let i=1;i<tokens.length-1;i++) {
    if(['(','[','{'].includes(tokens[i].value)){i=closing(tokens,i);if(i<0)return null;continue;}
    if(tokens[i].value==='.'&&tokens[i+1]?.value==='.'&&tokens[i+2]?.value==='.') {props.push({spread:tokens[i+3]?.value});i+=3;continue;}
    if(tokens[i+1]?.value===':')props.push({key:tokens[i].value,value:tokens[i+2]});
  }
  return props;
}
function postOptions(tokens) {
  const props=topProperties(tokens);if(!props||props.some(p=>p.spread))return false;
  const methods=props.filter(p=>p.key==='method');return methods.length===1&&methods[0].value?.kind==='string'&&methods[0].value.value.toUpperCase()==='POST';
}
function endpointPath(value) {if(!validPath(value))return '';return value;}
function facts(source,file,env) {
  source=source.replace(/<!--[\s\S]*?-->/g,comment=>comment.replace(/[^\r\n]/g,' '));
  const tokens=lex(source),constants=constantsIn(tokens,env),front=[],back=[];
  const add=(list,path,t,kind)=>{if(validPath(path))list.push({path,file,line:t.line,kind});};
  // Direct app.post('/path', ...). Router-relative paths alone never imply a mounted prefix.
  const appNames=new Set();
  for(let i=0;i<tokens.length;i++)if(['const','let'].includes(tokens[i].value)&&tokens[i+2]?.value==='='&&['express','fastify','Fastify'].includes(tokens[i+3]?.value)&&tokens[i+4]?.value==='(')appNames.add(tokens[i+1].value);
  for(let i=0;i<tokens.length;i++) {
    const t=tokens[i];
    if(t.kind==='identifier'&&appNames.has(t.value)&&tokens[i+1]?.value==='.'&&tokens[i+2]?.value==='post'&&tokens[i+3]?.value==='('){const call=args(tokens,i+3);if(call)add(back,expression(call.parts[0],constants,env),t,'backend POST');}
    if(t.kind==='identifier'&&t.value==='if'&&tokens[i+1]?.value==='('){
      const end=closing(tokens,i+1);const condition=tokens.slice(i+2,end);const values=condition.map(t=>t.value);
      // Positive conjunction only; OR/negation/nested branch can't establish a POST route.
      if(end>0&&!values.some(v=>['||','!'].includes(v))&&condition.some((t,j)=>t.kind==='identifier'&&t.value==='method'&&condition[j-1]?.value==='.'&&['===','=='].includes(condition[j+1]?.value)&&condition[j+2]?.value==='POST')){
        const route=condition.findIndex((t,j)=>t.kind==='identifier'&&['pathname','url','path'].includes(t.value)&&condition[j-1]?.value==='.'&&['===','=='].includes(condition[j+1]?.value)&&condition[j+2]?.kind==='string');
        if(route>=0)add(back,condition[route+2].value,t,'backend POST');
      }
    }
    if(t.kind==='identifier'&&t.value==='fetch'&&tokens[i+1]?.value==='('){const call=args(tokens,i+1);if(call&&postOptions(call.parts[1]))add(front,endpointPath(expression(call.parts[0],constants,env)),t,'frontend POST');}
  }
  // Follow a simple fetch wrapper only when its first argument is passed as BASE + parameter.
  const wrappers=new Map();
  for(let i=0;i<tokens.length;i++)if(tokens[i].value==='function'&&tokens[i+1]?.kind==='identifier'&&tokens[i+2]?.value==='('){
    const params=args(tokens,i+2);if(!params||params.parts[0]?.length!==1||tokens[params.end+1]?.value!=='{')continue;
    const end=closing(tokens,params.end+1),name=params.parts[0][0].value,optionsName=params.parts[1]?.length===1?params.parts[1][0].value:null;
    if(!optionsName)continue;
    const body=tokens.slice(params.end+2,end);
    for(let j=0;j<body.length;j++)if(body[j].value==='fetch'&&body[j+1]?.value==='('){const call=args(body,j+1);if(!call)continue;const url=call.parts[0],opts=call.parts[1],props=topProperties(opts);
      const forwards=opts?.length===1&&opts[0].value===optionsName || (props&&props.some(p=>p.spread===optionsName)&&!props.some(p=>p.key==='method'||p.spread&&p.spread!==optionsName));
      if(!forwards)continue;
      if(url.at(-1)?.value===name&&url.at(-2)?.value==='+'){const base=expression(url.slice(0,-2),constants,env);if(typeof base==='string'&&base.startsWith('/')&&!base.startsWith('//'))wrappers.set(tokens[i+1].value,base);}}
  }
  for(let i=0;i<tokens.length;i++)if(wrappers.has(tokens[i].value)&&tokens[i+1]?.value==='('){const call=args(tokens,i+1);if(call&&postOptions(call.parts[1])){const path=expression(call.parts[0],constants,env);if(typeof path==='string')add(front,wrappers.get(tokens[i].value)+path,tokens[i],'frontend POST via fetch wrapper');}}
  // Next App Router paths derive from route file location, excluding route groups/dynamic segments.
  const next=file.match(/^(?:src\/)?app\/(.+)\/route\.[cm]?[jt]s$/);
  if(next && tokens.some((t,i)=>t.kind==='identifier'&&t.value==='export'&&((tokens[i+1]?.value==='async'&&tokens[i+2]?.value==='function'&&tokens[i+3]?.value==='POST')||(tokens[i+1]?.value==='function'&&tokens[i+2]?.value==='POST')))){
    const segments=next[1].split('/').filter(v=>!/^\(.+\)$/.test(v));
    if(!segments.some(v=>/[\[\]@]/.test(v)))add(back,'/'+segments.join('/'),tokens.find(t=>t.value==='POST')||{line:1},'Next POST route');
  }
  return{front,back};
}

export async function scanProject(project,{backend,framework,entry}={}) {
  const root=await realpath(resolve(project));let count=0,truncated=false;const files=[],packages=[];
  async function walk(dir,depth=0){
    if(depth>7){truncated=true;return;}
    for(const item of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))) {
      if(item.isSymbolicLink())continue;
      if(count>=600){truncated=true;return;}
      const path=join(dir,item.name),name=posix(relative(root,path));
      if(item.isDirectory()){if(!ignored.has(item.name)&&!item.name.startsWith('.'))await walk(path,depth+1);}
      else if(item.isFile()&&(sourceFile.test(item.name)||item.name==='package.json')){count++;if((await stat(path)).size>262144){truncated=true;continue;}const source=await text(path);if(item.name==='package.json'){try{packages.push({dir:posix(relative(root,dir))||'.',data:JSON.parse(source)});}catch{}}else files.push({file:name,source});}
    }
  }
  await walk(root);
  const pkg=packages.find(p=>p.dir==='.')?.data||{};const deps={...pkg.dependencies,...pkg.devDependencies};
  const detectedFramework=deps.next?'next':deps.vite?(deps.vue?'vue':'vite'):files.some(f=>f.file==='index.html')?'html':'';
  const chosenFramework=framework||detectedFramework;
  const entries=chosenFramework==='next'?['src/app/layout.tsx','src/app/layout.jsx','app/layout.tsx','app/layout.jsx']:chosenFramework==='html'?['index.html']:['src/main.tsx','src/main.jsx','src/main.ts','src/main.js'];
  const entryCandidates=entries.filter(name=>files.some(f=>f.file===name));
  const env={...envValues(await text(join(root,'.env'))),...envValues(await text(join(root,'.env.local')))};
  let envAmbiguous=false;
  for(const name of ['.env.development','.env.production','.env.development.local','.env.production.local']) {
    const variant=envValues(await text(join(root,name)));
    for(const [key,value] of Object.entries(variant)) if(value!==env[key]&&files.some(f=>f.source.includes(key)))envAmbiguous=true;
  }
  const all=files.map(f=>facts(f.source,f.file,env));
  let back=all.flatMap(f=>f.back),front=all.flatMap(f=>f.front);
  const backendCandidates=packages.filter(p=>p.data.name&&((p.dir==='.'&&deps.next)||Object.values(p.data.scripts||{}).some(v=>/^\s*(?:node|tsx|ts-node)\b/.test(v))||['express','fastify','koa','@nestjs/core'].some(v=>(p.data.dependencies||{})[v]))).map(p=>p.dir);
  const chosenBackend=backend|| (backendCandidates.length===1?backendCandidates[0]:'');
  if(chosenBackend) {
    const absolute=resolve(root,chosenBackend),rel=posix(relative(root,absolute));
    if(rel==='..'||rel.startsWith('../')||isAbsolute(rel))throw new Error('Backend harus berada di dalam proyek brand.');
    back=back.filter(f=>!rel||f.file.startsWith(rel+'/'));
    front=front.filter(f=>!rel||!f.file.startsWith(rel+'/'));
  }
  const grouped=new Map();
  for(const fact of back.filter(f=>/(?:checkout|orders?|purchase)(?:\/|$)/i.test(f.path))){if(!grouped.has(fact.path))grouped.set(fact.path,[]);grouped.get(fact.path).push(fact);}
  const checkoutCandidates=[...grouped].map(([path,evidence])=>({path,confidence:front.some(f=>f.path===path)?'matched':'backend-only',evidence:[...evidence,...front.filter(f=>f.path===path)]}));
  const matches=checkoutCandidates.filter(c=>c.confidence==='matched');
  const checkoutPath=!truncated&&!envAmbiguous&&matches.length===1&&chosenBackend?matches[0].path:'';
  return {backend:chosenBackend,backendCandidates,framework:chosenFramework,entry:entry||(entryCandidates.length===1?entryCandidates[0]:''),entryCandidates,checkoutPath,checkoutCandidates,truncated,envAmbiguous,
    reason:envAmbiguous?'Konfigurasi env antar mode berbeda; pilih path sesuai lingkungan website.':truncated?'Pemindaian dibatasi; pilih secara eksplisit.':matches.length>1?'Beberapa endpoint checkout cocok; pilih secara eksplisit.':!checkoutPath?'Belum ada satu kecocokan frontend/backend yang pasti; masukkan atau pilih path.':''};
}

// Internal helpers used for bounded adapter matching; never evaluate source.
export function sourceTokens(source) { return lex(source); }
export function closingToken(tokens,start) { return closing(tokens,start); }
