#!/usr/bin/env node
import { planConnect, applyConnect } from './connect.mjs';
import { createInterface } from 'node:readline/promises';
import { scanProject } from './scan.mjs';
import { Writable } from 'node:stream';
import { resolve, join } from 'node:path';
import { detect, readText, parseEnv, planSetup, applySetup, doctor } from './installer.mjs';

const args = process.argv.slice(2);
const command = args.shift() || 'help';
const options = {};
const names = {'connection':'connection','root':'root','backend':'backend','frontend':'framework','entry':'entry','merchant-id':'merchantId','conversion-url':'url','checkout-path':'checkoutPath'};
try {
  while(args.length) {
    const key = args.shift();
    if(['--yes','--dry-run','--no-install'].includes(key)) {options[key.slice(2)] = true;continue;}
    if(!key.startsWith('--') || !names[key.slice(2)] || !args[0] || args[0].startsWith('--')) throw new Error('Opsi tidak dikenali. Gunakan afihub help. Secret tidak diterima melalui argumen terminal.');
    options[names[key.slice(2)]] = args.shift();
  }
  if(command === 'help') console.log(`Afihub installer 0.4.0 (Node.js >=20)
  afihub connect    Pasang adapter pembayaran + SDK, build dan cek lokal
  afihub init       Panduan interaktif, backup perubahan, install SDK
  afihub scan       Pindai kode lokal tanpa perubahan atau eksekusi aplikasi
  afihub doctor     Periksa pemasangan lokal; tidak membuat transaksi
  Opsi init: --connection ./afihub.connect.json --root . --backend backend --frontend vite|vue|next|html
             --entry src/main.jsx --checkout-path /api/checkout
             --merchant-id UUID --conversion-url HTTPS_URL
             --dry-run --no-install --yes
  Secret dibaca dari .env BACKEND atau dimasukkan secara tersembunyi.
  Installer tidak mengubah payment gateway, menjalankan, atau menghentikan layanan.`);
  else if(command === 'scan') {
    console.log(JSON.stringify(await scanProject(options.root || '.',options),null,2));
  } else if(command === 'doctor') {
    const result = await doctor(options.root || '.');
    for (const [key,value] of Object.entries(result)) console.log(`${typeof value === 'boolean' ? value ? 'OK' : 'PERIKSA' : 'INFO'} ${key}: ${value}`);
    if(Object.values(result).includes(false)) process.exitCode = 1;
  } else if(['init','connect'].includes(command)) {
    const root = resolve(options.root || '.');
    if(options.connection) {
      const file = resolve(root,options.connection);
      const {relative,isAbsolute} = await import('node:path');
      const rel = relative(root,file);
      if(rel.startsWith('..') || isAbsolute(rel)) throw new Error('Simpan file konfigurasi privat di dalam proyek brand.');
      let connection;
      let raw;
      try { raw = await (await import('node:fs/promises')).readFile(file,'utf8'); } catch(e) { if(e.code==='ENOENT') throw new Error('File konfigurasi privat tidak ditemukan. Unduh afihub.connect.json dari Brand Portal dan simpan di root proyek brand.'); throw new Error('File konfigurasi privat tidak dapat dibaca.'); }
      try { connection = JSON.parse(raw.replace(/^\uFEFF/,'')); } catch { throw new Error('File konfigurasi privat bukan JSON yang valid.'); }
      if(!connection || typeof connection !== 'object') throw new Error('File konfigurasi privat tidak valid.');
      options.merchantId ||= connection.merchantId; options.url ||= connection.url; options.secret = connection.secret;
    }
    let rl,muted = false;
    const output = new Writable({write(chunk,encoding,callback){if(!muted)process.stdout.write(chunk);callback();}});
    const ask = async (label,fallback='') => {
      rl ??= createInterface({input:process.stdin,output,terminal:process.stdin.isTTY && process.stdout.isTTY});
      const answer = await rl.question(label+(fallback ? ' ['+fallback+']' : '')+': ');
      return answer.trim() || fallback;
    };
    try {
      if(!options.yes) {
        if(!process.stdin.isTTY) throw new Error('Terminal interaktif diperlukan. Gunakan --yes dengan konfigurasi backend/.env untuk otomasi.');
        console.log(command === 'connect' ? 'Connect: adapter akan menghubungkan SDK ke backend yang dikenali. Gateway tetap milik brand.' : 'Pasang SDK tracking/helper; pembayaran belum dihubungkan otomatis.');
        const required = async(label,fallback='',choices=[]) => {
          if(!fallback&&choices.length) {console.log('Pilihan (ketik nomor atau nilai lain):');choices.forEach((value,i)=>console.log('  '+(i+1)+'. '+value));}
          while(true) { const answer=await ask(label,fallback); if(answer) {if(!fallback&&/^\d+$/.test(answer)&&choices[Number(answer)-1])return choices[Number(answer)-1];return answer;} console.log('Belum ada saran yang pasti; isi jawaban atau batalkan dengan Ctrl+C.'); }
        };
        let found = await scanProject(root,options);
        console.log('Pemindaian lokal selesai; kode brand tidak dieksekusi.');
        options.backend ||= await required('Folder backend Node.js',found.backend,found.backendCandidates);
        options.framework ||= await required('Frontend (vite, vue, next, html)',found.framework);
        found = await scanProject(root,options);
        options.entry ||= await required('File entry/frontend layout',found.entry,found.entryCandidates);
        if(found.checkoutPath) {
          console.log('Saran checkout: '+found.checkoutPath+' (request frontend cocok dengan route POST backend)');
          for(const e of found.checkoutCandidates.find(c=>c.path===found.checkoutPath).evidence) console.log('  '+e.file+':'+e.line+' — '+e.kind);
        } else console.log(found.reason);
        options.checkoutPath ||= await required('Path POST JSON checkout brand (same-origin)',found.checkoutPath,found.checkoutCandidates.map(c=>c.path));
        const env = parseEnv(await readText(join(root,options.backend,'.env')));
        options.merchantId ||= await ask('Merchant ID dari halaman Integrasi Afihub',env.AFIHUB_MERCHANT_ID);
        options.url ||= await ask('Conversion URL dari halaman Integrasi Afihub',env.AFIHUB_CONVERSION_URL);
        options.secret ||= env.AFIHUB_WEBHOOK_SECRET || process.env.AFIHUB_WEBHOOK_SECRET;
        if(!options.secret) {
          process.stdout.write('Secret dari halaman Integrasi (input disembunyikan): ');
          muted = true;
          options.secret = (await ask('')).trim();
          muted = false;process.stdout.write('\n');
        } else console.log('Secret backend tersedia; nilainya tidak ditampilkan.');
      } else options.secret ||= process.env.AFIHUB_WEBHOOK_SECRET;
      const plan = await (command === 'connect' ? planConnect : planSetup)({...options,root});
      if(plan.report.adapter) {console.log('Adapter: '+plan.report.adapter.id);for(const path of plan.writes.keys())console.log('  '+(await import('node:path')).relative(root,path));}
      console.log('Frontend: '+plan.framework+'; backend: '+plan.report.backend+'; checkout: '+plan.report.checkoutPath);
      console.log('File disiapkan: '+[...plan.writes.keys()].length+'. Backup file yang berubah: .afihub/backups/ (diabaikan Git).');
      if(!options['dry-run']) {
        if(!options.yes && (await ask('Terapkan dan install SDK? (ya/tidak)','ya')).toLowerCase() !== 'ya') { console.log('Dibatalkan; tidak ada file diubah.'); }
        else {
          const result = await (command === 'connect' ? applyConnect : applySetup)(plan,{install:!options['no-install']});
          console.log('Pemasangan selesai. '+result.changed.length+' file disiapkan/diubah.');
          for(const instruction of plan.report.instructions) console.log('BERIKUTNYA: '+instruction);
          console.log(command === 'connect' ? 'Build dan pemeriksaan adapter lokal lolos. Jalankan afihub doctor; restart layanan sendiri, lalu uji sandbox.' : 'Jalankan build, lalu afihub doctor. Restart layanan sendiri agar konfigurasi baru terbaca.');
        }
      } else console.log('Dry run: tidak ada file diubah dan tidak ada npm install.');
    } finally {muted = false;rl?.close();}
  } else throw new Error('Perintah tidak dikenal. Gunakan afihub help.');
} catch(error) {
  // Configuration/SDK errors use safe codes; never print env, payloads, or credentials.
  console.error('Afihub: '+(error.code || error.message));process.exitCode = 1;
}
