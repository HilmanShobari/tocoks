export const delivery = `async deliver(event) {
    try {
      const order = this.get(event.order_id);
      if (!order) throw new AfihubError('order_not_found');
      const config = await this.config(order.brand_slug);
      if (!config.merchant_id || !config.secret_key) throw new Error('merchant_not_configured');
      if (order.merchant_id && order.merchant_id !== config.merchant_id) throw new AfihubError('merchant_mapping_changed');
      if (!order.merchant_id) { order.merchant_id = config.merchant_id; this.save(order); }
      const afihub = createAfihubClient({ merchantId: config.merchant_id, secret: config.secret_key,
        url: this.afihubUrl, allowHttp: process.env.NODE_ENV !== 'production', fetchImpl: this.fetch });
      await afihub.sendOrder({ order_id: order.id,
        session_token: order.afihub_click_id ?? order.session_token ?? '',
        amount: order.subtotal, currency: 'IDR',
        customer_fingerprint: order.customer_fingerprint,
        customer_ip: order.customer_ip, customer_user_agent: order.customer_user_agent,
        items: order.items,
      }, { status: event.status,
        paymentVerified: ['paid', 'fulfilled', 'completed', 'refunded', 'cancelled'].includes(order.status) });
      this.db.prepare("UPDATE outbox SET delivered=1,last_error='' WHERE id=?").run(event.id);
    } catch (error) {
      const attempts = event.attempts + 1;
      const blocked = error instanceof AfihubError && !error.retryable;
      const nextAttempt = blocked ? Number.MAX_SAFE_INTEGER
        : Date.now() + Math.min(300000, 1000 * 2 ** Math.min(attempts, 8));
      this.db.prepare('UPDATE outbox SET attempts=?,next_attempt=?,last_error=? WHERE id=?').run(
        attempts, nextAttempt, blocked ? error.code + '_requires_fix'
          : error.message === 'merchant_not_configured' ? error.message : 'delivery_failed', event.id);
    }
  }`;
export const merchantConfig = `export async function loadMerchants(path) {
  // Explicit legacy callers remain compatible; the running server calls this WITHOUT a file.
  if (path !== undefined) return loadLegacyMerchants(path);
  const config = configFromEnv();
  if (!config) return {};
  const origin = new URL(process.env.STOREFRONT_STORE_URL || defaultStoreUrl);
  if (!['http:', 'https:'].includes(origin.protocol) || origin.pathname !== '/' ||
      origin.search || origin.hash || origin.username || origin.password) {
    throw new Error('STOREFRONT_STORE_URL harus berupa origin website.');
  }
  return { [brandSlug]: { merchant_id: config.merchantId, secret_key: config.secret, store_url: origin.origin } };
}`;
export const resumeBlocked = `this.db.prepare('UPDATE outbox SET next_attempt=0 WHERE delivered=0 AND next_attempt=?').run(Number.MAX_SAFE_INTEGER);`;
