import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {sourceTokens,closingToken} from '../scan.mjs';
import {delivery,merchantConfig,resumeBlocked} from './outbox-templates.mjs';

const profile=JSON.parse(await readFile(new URL('./outbox-profile.json',import.meta.url),'utf8'));
export const adapterID='node-sqlite-checkout-outbox-v1';
export const digest=text=>createHash('sha256').update(text).digest('hex');
export function fingerprint(source,type='checkout') {
  let tokens=sourceTokens(source.replace(/\r\n?/g,'\n'));
  if(type==='config') {
    // Only deployment identity/port/origin vary between copies of this known backend.
    for(let i=0;i<tokens.length;i++)if(tokens[i].value==='const'&&['brandSlug','defaultPort','defaultStoreUrl'].includes(tokens[i+1]?.value)&&tokens[i+2]?.value==='='){
      let end=i+3;while(end<tokens.length&&tokens[end].value!==';')end++;
      const value=tokens.slice(i+3,end);
      const name=tokens[i+1].value;
      if(name==='defaultPort') {
        const digits=value.map(t=>t.value).join('');
        if(!/^\d+$/.test(digits)||Number(digits)<1||Number(digits)>65535)throw new Error('Adapter hanya menerima port literal.');
      } else {
        if(value.length!==1||value[0].kind!=='string')throw new Error('Adapter hanya menerima identitas/origin literal.');
        if(name==='brandSlug'&&!/^[a-z0-9-]{1,80}$/.test(value[0].value))throw new Error('Identitas brand tidak didukung.');
        if(name==='defaultStoreUrl') {const url=new URL(value[0].value);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw new Error('Origin brand tidak didukung.');}
      }
      tokens.splice(i+3,end-i-3,{kind:'literal',value:'deployment-value'});
    }
  }
  return digest(JSON.stringify(tokens.map(t=>[t.kind,t.kind==='string'&&t.value.startsWith('PRAGMA journal_mode=WAL;')?t.value.replace(/\s+/g,' ').trim():t.value])));
}
function countReplace(source,from,to) {
  if(source.split(from).length!==2)throw new Error('Adapter tidak cocok: anchor kode berubah. Gunakan panduan manual.');
  return source.replace(from,to);
}
function method(source,name) {
  const tokens=sourceTokens(source);const candidates=[];
  for(let i=0;i<tokens.length;i++)if(tokens[i].kind==='identifier'&&tokens[i].value===name&&tokens[i+1]?.value==='('){
    const paramsEnd=closingToken(tokens,i+1);if(paramsEnd<0||tokens[paramsEnd+1]?.value!=='{')continue;
    const bodyEnd=closingToken(tokens,paramsEnd+1);if(bodyEnd<0)continue;
    const start=tokens[i-1]?.value==='async'?tokens[i-1].start:tokens[i].start;
    candidates.push({start,end:tokens[bodyEnd].end});
  }
  if(candidates.length!==1)throw new Error('Adapter tidak cocok: method '+name+' tidak tunggal.');
  return candidates[0];
}
export function removeKnownPaste(source) {
  // Only the exact old guide paste is recoverable, verified again by the full-source fingerprint.
  source=source.replace(/^import\s*\{\s*createAfihubClient(?:\s*,\s*AfihubError)?\s*\}\s*from\s*['"]\.\/afihub\/client\.mjs['"];?\s*$/gm,'');
  source=source.replace(/^const\s+afihub\s*=\s*createAfihubClient\(\);?\s*$/gm,'');
  source=source.replace(/await\s+afihub\.sendOrder\(transaction,\s*\{\s*status:\s*event\.status,\s*paymentVerified:\s*true,?\s*\}\);?/g,'');
  source=source.replace(/afihub_click_id:\s*sessionToken,\s*/g,'');
  return source;
}
export function patchOutbox({checkout,config,server}) {
  const base=removeKnownPaste(checkout);
  if(fingerprint(base)!==profile.checkout||fingerprint(config,'config')!==profile.config||fingerprint(server,'server')!==profile.server) {
    throw new Error('Adapter belum mendukung struktur/perubahan backend ini. Tidak ada file diubah. Gunakan panduan manual; verifikasi pembayaran tidak akan ditebak.');
  }
  const target=method(base,'deliver');
  let updated=base.slice(0,target.start)+delivery+base.slice(target.end);
  const tokens=sourceTokens(updated);
  // Locate the new order object; retain the rest of create(), prices, tokens and invoice lifecycle.
  const orderIndex=tokens.findIndex((t,i)=>t.value==='session_token'&&tokens[i+1]?.value===':'&&tokens[i+2]?.value==='sessionToken');
  if(orderIndex<0)throw new Error('Adapter tidak menemukan penyimpanan klik.');
  const valueEnd=tokens[orderIndex+2].end;
  updated=updated.slice(0,valueEnd)+', afihub_click_id: sessionToken'+updated.slice(valueEnd);
  const ctor=method(updated,'constructor');
  updated=updated.slice(0,ctor.end-1)+'  '+resumeBlocked+'\n  '+updated.slice(ctor.end-1);
  updated="import { createAfihubClient, AfihubError } from './afihub/client.mjs';\n"+updated;
  const renamed=config.replace(/export\s+async\s+function\s+loadMerchants\(/,'async function loadLegacyMerchants(');
  const updatedConfig="import { configFromEnv } from '@afihub/node';\n"+renamed+'\n'+merchantConfig+'\n';
  const updatedServer=countReplace(server,"(process.env.STOREFRONT_AFIHUB_API_URL || 'http://localhost:8080/api/v1').replace(/\\/$/, '') + '/webhooks/custom'",'process.env.AFIHUB_CONVERSION_URL');
  const changes={checkout:updated,config:updatedConfig,server:updatedServer};
  return {id:adapterID,changes, fingerprints:Object.fromEntries(Object.entries(changes).map(([key,value])=>[key,fingerprint(value,key)]))};
}
export function validateConnected(sources,expected) {
  try {return ['checkout','config','server'].every(key=>fingerprint(sources[key],key)===profile.connected?.[key]&&expected[key]===profile.connected?.[key]);} catch {return false;}
}
