// Invoked in a child process. Only imports a fingerprint-approved Checkout library.
// All gateway/SDK requests use an injected fake transport, and SQLite is :memory:.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {randomUUID,createHmac} from 'node:crypto';
import {validateConnected} from './adapters/outbox.mjs';

export async function verifyAdapter(backend,expected) {
  const source=Object.fromEntries(await Promise.all(['checkout','config','server'].map(async name=>[name,await readFile(join(backend,name+'.mjs'),'utf8')])));
  if(!validateConnected(source,expected))throw new Error('Kode adapter berubah sebelum pemeriksaan.');
  // Defense in depth: an unintended global fetch cannot reach either real provider.
  globalThis.fetch=async()=>{throw new Error('Real network blocked in adapter verification');};
  const {Checkout}=await import(pathToFileURL(join(backend,'checkout.mjs')).href);
  const merchant=randomUUID(),secret='offline-adapter-fixture';
  const invoices=new Map(),receipts=[];let outage=false,code=200;
  const fetchImpl=async(url,options)=>{
    if(url.startsWith('https://api.xendit.co/')) {
      if(options.method==='POST') {
        const request=JSON.parse(options.body);
        const invoice={id:'invoice_'+request.external_id,external_id:request.external_id,invoice_url:'https://checkout.xendit.co/fixture',amount:request.amount,currency:'IDR',status:'PENDING'};
        invoices.set(invoice.id,invoice);return Response.json(invoice);
      }
      const endpoint=new URL(url);
      return Response.json(endpoint.search?[...invoices.values()].filter(i=>i.external_id===endpoint.searchParams.get('external_id')):invoices.get(endpoint.pathname.split('/').at(-1)));
    }
    assert.equal(url,'https://afihub.invalid/api/v1/webhooks/custom');
    if(outage)throw new Error('Simulated offline');
    if(code!==200)return Response.json({}, {status:code});
    assert.equal(options.headers['X-AfiHub-Signature'],'sha256='+createHmac('sha256',secret).update(options.body).digest('hex'));
    const payload=JSON.parse(options.body);assert.equal(options.headers['X-AfiHub-Timestamp'],payload.timestamp);receipts.push(payload);
    return Response.json({success:true,data:{status:payload.session_token?'pending':'organic',conversion_id:'offline-fixture'}});
  };
  const opts={dbPath:':memory:',catalogs:{fixture:{slug:'fixture',origin:'https://brand.invalid',products:[{id:'fixture-sku',name:'Fixture',price:20000}]}},merchants:async()=>({fixture:{merchant_id:merchant,secret_key:secret,store_url:'https://brand.invalid'}}),apiKey:'xnd_development_offline_fixture',callbackToken:'fixture-callback',adminToken:'fixture-admin',afihubUrl:'https://afihub.invalid/api/v1/webhooks/custom',fetchImpl};
  const checkout=new Checkout(opts);
  const input=()=>({brand_slug:'fixture',checkout_key:randomUUID(),order_token:randomUUID(),session_token:'fixture_click',items:[{product_id:'fixture-sku',quantity:1,unit_price:1}],customer:{name:'Fixture',email:'fixture@example.invalid',phone:'000',address:'Fixture'},return_url:'https://brand.invalid/checkout/result'});
  try {
    const request=input();const result=await checkout.create(request);assert.equal(result.total,35000);assert.equal(receipts.length,0);assert.equal(checkout.get(result.order_id).afihub_click_id,'fixture_click');
    await checkout.create(request);assert.equal(invoices.size,1);
    const order=checkout.get(result.order_id),paid={...invoices.get(order.invoice_id),status:'PAID',paid_amount:35000};
    assert.throws(()=>checkout.callback(paid,'wrong-token'));assert.equal(receipts.length,0);
    assert.throws(()=>checkout.callback({...paid,amount:1},'fixture-callback'));
    checkout.callback(paid,'fixture-callback');checkout.callback(paid,'fixture-callback');outage=true;await checkout.tick();assert.equal(receipts.length,0);assert.equal(checkout.db.prepare('SELECT delivered FROM outbox').get().delivered,0);
    outage=false;checkout.db.prepare('UPDATE outbox SET next_attempt=0').run();await checkout.tick();assert.equal(receipts.length,1);assert.equal(receipts[0].amount,20000);assert.equal(receipts[0].items[0].unit_price,20000);assert.equal(receipts[0].session_token,'fixture_click');
    const key=receipts[0].items[0].line_item_key;
    checkout.callback(paid,'fixture-callback');await checkout.tick();assert.equal(receipts.length,1);
    checkout.updateStatus(order.id,'fixture','refunded','fixture-admin');await checkout.tick();assert.equal(receipts[1].status,'refunded');assert.equal(receipts[1].items[0].line_item_key,key);
    const organic=input();organic.session_token='';const other=await checkout.create(organic);const stored=checkout.get(other.order_id);const invoice=invoices.get(stored.invoice_id);
    checkout.callback({...invoice,status:'PAID',paid_amount:invoice.amount},'fixture-callback');code=401;await checkout.tick();assert.equal(checkout.db.prepare('SELECT next_attempt FROM outbox WHERE order_id=?').get(other.order_id).next_attempt,Number.MAX_SAFE_INTEGER);code=200;
    return {paymentVerification:true,serverPricing:true,clickPersistence:true,idempotency:true,retry:true,refund:true,blockedErrors:true,liveConversion:false};
  } finally {checkout.close();}
}
if(process.argv[1]&&pathToFileURL(resolve(process.argv[1])).href===import.meta.url) {
  try {const expected=JSON.parse(await readFile(process.argv[3],'utf8'));const result=await verifyAdapter(resolve(process.argv[2]),expected);console.log(JSON.stringify(result));}
  catch {console.error('Pemeriksaan adapter gagal; tidak ada transaksi nyata dikirim.');process.exitCode=1;}
}
