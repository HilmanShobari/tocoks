# Afihub installer 0.2.0

Jalankan dari root website brand. Node.js >=20, frontend Vite/React, Vue/Vite, Next.js App Router atau HTML statis; backend Node.js. Backend PHP/Python/Go dan Next Pages Router memakai panduan manual. Paket belum dipublikasikan ke npm registry.

1. Unduh `afihub-cli-0.2.0.tgz` dari halaman Integrasi Brand Portal, simpan di root proyek.
2. `npm install --save-dev ./afihub-cli-0.2.0.tgz`
3. `npx --no-install afihub init --connection ./afihub.connect.json`
4. Jawab folder backend, entry frontend, path checkout POST JSON yang persis, Merchant ID, URL konversi dan secret. Secret disembunyikan dan hanya ditulis ke environment backend.
5. Jalankan build sendiri, `npx --no-install afihub doctor`, kemudian restart layanan sendiri.

Installer sudah membawa kedua SDK: tidak perlu mengunduh/browser/node satu per satu. Tidak menjalankan/menghentikan aplikasi, mengubah gateway atau membuat pesanan. Default installer otomatis memasang dependencies dari tarball vendor. Backend harus memiliki package.json. CommonJS dapat memakai dynamic import helper `.mjs`.

## Yang otomatis

- Mendeteksi frontend dan entry yang umum; Anda dapat mengganti hasil deteksi.
- Menambahkan file tracking dan import entry / Next client Provider / script HTML.
- Menambahkan Merchant ID publik frontend dan tiga env backend (konfigurasi lain dipertahankan).
- Fetch interceptor hanya menyisipkan `session_token` pada POST JSON same-origin ke path checkout persis yang Anda pilih. Request lain/form/upload/cross-origin tidak disentuh; token eksplisit tidak ditimpa. Untuk Axios/XHR/form atau API cross-origin gunakan `afihub.getClickId()` secara manual. Persetujuan tracking harus ditangani website; gunakan pemasangan manual setelah consent jika diperlukan.
- Menyiapkan helper backend `backend/afihub/client.mjs`.
- Backup file yang berubah di `.afihub/backups/`; directory ini dan env diabaikan Git. Jangan bagikan backup karena dapat berisi secret. File env yang sudah dilacak Git ditolak. Installer menolak symlink keluar proyek dan file generated yang diubah; tidak memakai --force.
- Laporan `afihub.setup.json` tidak berisi secret dan selalu menyatakan pembayaran/live conversion belum diverifikasi. Doctor hanya memeriksa pemasangan lokal, bukan bukti komisi.

## Dua sambungan backend yang tetap diperlukan

Installer tidak tahu struktur database dan callback payment gateway milik brand:

1. Simpan `request.session_token` sebagai `order.afihub_click_id` **sebelum** membuat invoice.
2. Pada outbox worker yang membaca order berbayar terverifikasi:

```js
import { createAfihubClient } from './afihub/client.mjs';
// Muat .env dahulu, misalnya node --env-file=.env server.mjs.
const afihub = createAfihubClient();
// transaction dibentuk dari database brand, bukan payload browser.
const result = await afihub.sendOrder(transaction, {
  status: event.status, paymentVerified: true,
});
```

Transaction: order_id stabil, session_token dari order, amount integer IDR subtotal setelah diskon tanpa ongkir/pajak, items sesuai SKU katalog dan total gross_amount sama dengan amount. Simpan outbox bersama perubahan status order dalam transaksi database, pertahankan urutan status per order. Network/408/429/5xx retryable dengan backoff; 4xx lain blocked sampai diperbaiki. Tandai delivered hanya setelah sukses; cek hasil bisnis pada result.status. Redirect halaman sukses bukan bukti pembayaran.

Uji link kreator disetujui → checkout sandbox → verifikasi gateway → event → Konversi dan komisi Afihub. Uji event ulang, retry/restart worker, organic dan refund. Jangan mengirim transaksi contoh untuk membuat status integrasi tampak aktif.

## Pemeriksaan tanpa mengubah file

```sh
npx --no-install afihub init --dry-run
npx --no-install afihub doctor
```

Noninteraktif (secret sudah di backend/.env atau environment proses; jangan tulis secret di argumen):

```sh
npx --no-install afihub init --yes --backend backend --checkout-path /api/v1/storefront/checkout
```

`--no-install` menghasilkan file/vendor tetapi menunda npm install. Init dapat dijalankan ulang dengan opsi yang sama; file sama tidak diubah. Jika npm install gagal, backup dan scaffolding tetap tersedia untuk diperbaiki dan init dijalankan ulang. Dry run juga memeriksa konflik dan konfigurasi; tidak mencetak nilainya.

Konfigurasi privat dari Brand Portal: unduh afihub.connect.json ke root proyek. Opsi --connection membaca merchantId, url, dan secret tanpa mencetak nilainya; file otomatis diabaikan Git. Hapus file unduhan setelah pemasangan. Jangan bagikan atau commit. Opsi ini menghilangkan kebutuhan menyalin env/secret satu per satu.
