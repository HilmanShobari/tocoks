#!/usr/bin/env node
import { createInterface } from 'node:readline/promises';
import { Writable } from 'node:stream';
import { resolve, join } from 'node:path';
import { detect, readText, parseEnv, planSetup, applySetup, doctor } from './installer.mjs';

const args = process.argv.slice(2);
const command = args.shift() || 'help';
const options = {};
const names = {'connection':'connection','root':'root','backend':'backend','frontend':'framework','entry':'entry','merchant-id':'merchantId','conversion-url':'url','checkout-path':'checkoutPath'};
try {
  while(args.length) {
    const key = args.shift();
    if(['--yes','--dry-run','--no-install'].includes(key)) {options[key.slice(2)] = true;continue;}
    if(!key.startsWith('--') || !names[key.slice(2)] || !args[0] || args[0].startsWith('--')) throw new Error('Opsi tidak dikenali. Gunakan afihub help. Secret tidak diterima melalui argumen terminal.');
    options[names[key.slice(2)]] = args.shift();
  }
  if(command === 'help') console.log(`Afihub installer 0.2.0 (Node.js >=20)
  afihub init       Panduan interaktif, backup perubahan, install SDK
  afihub doctor     Periksa pemasangan lokal; tidak membuat transaksi
  Opsi init: --connection ./afihub.connect.json --root . --backend backend --frontend vite|vue|next|html
             --entry src/main.jsx --checkout-path /api/checkout
             --merchant-id UUID --conversion-url HTTPS_URL
             --dry-run --no-install --yes
  Secret dibaca dari .env BACKEND atau dimasukkan secara tersembunyi.
  Installer tidak mengubah payment gateway, menjalankan, atau menghentikan layanan.`);
  else if(command === 'doctor') {
    const result = await doctor(options.root || '.');
    for (const [key,value] of Object.entries(result)) console.log(`${typeof value === 'boolean' ? value ? 'OK' : 'PERIKSA' : 'INFO'} ${key}: ${value}`);
    if(Object.values(result).includes(false)) process.exitCode = 1;
  } else if(command === 'init') {
    const root = resolve(options.root || '.');
    if(options.connection) {
      const file = resolve(root,options.connection);
      const {relative,isAbsolute} = await import('node:path');
      const rel = relative(root,file);
      if(rel.startsWith('..') || isAbsolute(rel)) throw new Error('Simpan file konfigurasi privat di dalam proyek brand.');
      let connection;
      try { connection = JSON.parse(await readText(file)); } catch { throw new Error('File konfigurasi privat bukan JSON yang valid.'); }
      if(!connection || typeof connection !== 'object') throw new Error('File konfigurasi privat tidak valid.');
      options.merchantId ||= connection.merchantId; options.url ||= connection.url; options.secret = connection.secret;
    }
    let rl,muted = false;
    const output = new Writable({write(chunk,encoding,callback){if(!muted)process.stdout.write(chunk);callback();}});
    const ask = async (label,fallback='') => {
      rl ??= createInterface({input:process.stdin,output,terminal:process.stdin.isTTY && process.stdout.isTTY});
      const answer = await rl.question(label+(fallback ? ' ['+fallback+']' : '')+': ');
      return answer.trim() || fallback;
    };
    try {
      if(!options.yes) {
        if(!process.stdin.isTTY) throw new Error('Terminal interaktif diperlukan. Gunakan --yes dengan konfigurasi backend/.env untuk otomasi.');
        console.log('Pasang Afihub di website brand. Perubahan kode pembayaran tidak dilakukan otomatis.');
        options.backend ||= await ask('Folder backend Node.js','backend');
        const found = await detect(root,options.backend);
        options.framework ||= await ask('Frontend (vite, vue, next, html)',found.framework);
        options.entry ||= await ask('File entry/frontend layout',found.entry);
        options.checkoutPath ||= await ask('Path POST JSON checkout brand (same-origin)','/api/checkout');
        const env = parseEnv(await readText(join(root,options.backend,'.env')));
        options.merchantId ||= await ask('Merchant ID dari halaman Integrasi Afihub',env.AFIHUB_MERCHANT_ID);
        options.url ||= await ask('Conversion URL dari halaman Integrasi Afihub',env.AFIHUB_CONVERSION_URL);
        options.secret ||= env.AFIHUB_WEBHOOK_SECRET || process.env.AFIHUB_WEBHOOK_SECRET;
        if(!options.secret) {
          process.stdout.write('Secret dari halaman Integrasi (input disembunyikan): ');
          muted = true;
          options.secret = (await ask('')).trim();
          muted = false;process.stdout.write('\n');
        } else console.log('Secret backend tersedia; nilainya tidak ditampilkan.');
      } else options.secret ||= process.env.AFIHUB_WEBHOOK_SECRET;
      const plan = await planSetup({...options,root});
      console.log('Frontend: '+plan.framework+'; backend: '+plan.report.backend+'; checkout: '+plan.report.checkoutPath);
      console.log('File disiapkan: '+[...plan.writes.keys()].length+'. Backup file yang berubah: .afihub/backups/ (diabaikan Git).');
      if(!options['dry-run']) {
        if(!options.yes && (await ask('Terapkan dan install SDK? (ya/tidak)','ya')).toLowerCase() !== 'ya') { console.log('Dibatalkan; tidak ada file diubah.'); }
        else {
          const result = await applySetup(plan,{install:!options['no-install']});
          console.log('Pemasangan selesai. '+result.changed.length+' file disiapkan/diubah.');
          for(const instruction of plan.report.instructions) console.log('BERIKUTNYA: '+instruction);
          console.log('Jalankan build, lalu afihub doctor. Restart layanan sendiri agar konfigurasi baru terbaca.');
        }
      } else console.log('Dry run: tidak ada file diubah dan tidak ada npm install.');
    } finally {muted = false;rl?.close();}
  } else throw new Error('Perintah tidak dikenal. Gunakan afihub help.');
} catch(error) {
  // Configuration/SDK errors use safe codes; never print env, payloads, or credentials.
  console.error('Afihub: '+(error.code || error.message));process.exitCode = 1;
}
