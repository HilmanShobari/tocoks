const uuid = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const validClick = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,256}$/.test(value);

/** Browser-only attribution. This library never contains a merchant secret. */
export function createTracker({ merchantId, attributionDays = 7 } = {}) {
  if (!uuid.test(merchantId || '')) throw new TypeError('merchantId must be a merchant UUID.');
  if (!Number.isInteger(attributionDays) || attributionDays < 1 || attributionDays > 90) throw new TypeError('attributionDays must be 1..90.');
  const storageKey = 'afihub:' + merchantId.toLowerCase();
  const browser = () => typeof window === 'undefined' ? null : window;
  function capture() {
    try {
      const target = browser();
      if (!target) return false;
      const value = new URLSearchParams(target.location.search).get('afihub_click_id');
      if (!validClick(value)) return false;
      target.localStorage.setItem(storageKey, JSON.stringify({ value, expires: Date.now() + attributionDays * 86400000 }));
      return true;
    } catch { return false; }
  }
  function getClickId() {
    try {
      const target = browser();
      if (!target) return '';
      const saved = JSON.parse(target.localStorage.getItem(storageKey) || 'null');
      if (validClick(saved?.value) && Number.isFinite(saved.expires) && saved.expires > Date.now()) return saved.value;
      target.localStorage.removeItem(storageKey);
    } catch { /* Storage/consent failures never block shopping. */ }
    return '';
  }
  function clear() { try { browser()?.localStorage.removeItem(storageKey); } catch {} }
  return Object.freeze({ capture, getClickId, clear, storageKey, version: '0.2.0' });
}

/** Opt-in interceptor: only same-origin JSON POST requests to the exact configured checkout paths. */
export function connectCheckout(tracker, { paths = [] } = {}) {
  if (!Array.isArray(paths) || !paths.length || paths.some(p => typeof p !== 'string' || !/^\/(?!\/)[^?#]*$/.test(p))) throw new TypeError('Use exact checkout paths, e.g. /api/checkout.');
  if (typeof window === 'undefined' || typeof window.fetch !== 'function') return () => {};
  const target = window;
  const original = target.fetch;
  let active = true;
  const wrapped = async function(input, init) {
    let changed;
    if (active) {
      try {
        const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url, target.location.href);
        if (url.origin === target.location.origin && paths.includes(url.pathname)) {
          const request = new Request(typeof input === 'string' || input instanceof URL ? url.href : input.clone(), init);
          if (request.method === 'POST' && request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() === 'application/json') {
            const payload = JSON.parse(await request.clone().text());
            if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
              tracker.capture();
              const click = tracker.getClickId();
              // Do not overwrite an explicit attribution chosen by the application.
              if (click && (payload.session_token === undefined || payload.session_token === '')) {
                payload.session_token = click;
                const headers = new Headers(request.headers);
                headers.delete('content-length');
                changed = new Request(request, { body: JSON.stringify(payload), headers });
              }
            }
          }
        }
      } catch { /* Malformed/non-JSON requests and blocked storage keep the original checkout. */ }
    }
    return changed ? original.call(target, changed) : original.call(target, input, init);
  };
  target.fetch = wrapped;
  return () => { active = false; if (target.fetch === wrapped) target.fetch = original; };
}
