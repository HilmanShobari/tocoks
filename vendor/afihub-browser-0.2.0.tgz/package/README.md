# @afihub/browser 0.1.0

Paket lokal tersedia melalui Brand Portal (belum npm registry).

```js
import { createTracker } from '@afihub/browser';
export const afihub = createTracker({ merchantId: 'MERCHANT_UUID_DARI_PORTAL' });
afihub.capture(); // browser entry point, before navigation; call again on SPA URL changes
const payload = { ...existingCheckoutPayload, session_token: afihub.getClickId() };
```

Konfigurasi tidak memuat secret. ID klik terakhir disimpan tujuh hari per merchant. capture() returns boolean; getClickId() returns empty string without valid attribution. clear() removes stored attribution. storageKey dapat diperiksa di DevTools. Respect consent sebelum capture/getClickId bila website membutuhkannya. SSR tidak mengakses window.

Untuk HTML, gunakan script dist/afihub.js dari URL Afihub dengan versi tetap dan atribut data-merchant-id. Global AfiHub.createTracker dan afihub tersedia jika atribut tersebut diisi. global afihub.getClickId() dapat ditambahkan pada request checkout yang sudah ada. Script saja tidak menyimpan ID klik di database backend atau membuktikan pembayaran.
