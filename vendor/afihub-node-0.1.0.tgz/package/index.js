import { createHmac } from 'node:crypto';
const uuid = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const events = { paid: 'order.paid', fulfilled: 'order.fulfilled', completed: 'order.completed', refunded: 'order.refunded', cancelled: 'order.cancelled' };
const text = (v, max = 256) => typeof v === 'string' && v.length > 0 && v.length <= max;
const money = value => Number.isSafeInteger(value) && value >= 0;
export class AfihubError extends Error {
  constructor(code, { httpStatus = 0, retryable = false } = {}) {
    super('Afihub request failed: ' + code);
    this.name = 'AfihubError'; this.code = code; this.httpStatus = httpStatus; this.retryable = retryable;
  }
}
export function configFromEnv(env = process.env) {
  const values = [env.AFIHUB_MERCHANT_ID, env.AFIHUB_WEBHOOK_SECRET, env.AFIHUB_CONVERSION_URL];
  if (values.every(value => !value)) return null;
  if (values.some(value => !value)) throw new AfihubError('configuration_incomplete');
  return validateConfig({ merchantId: values[0], secret: values[1], url: values[2], allowHttp: env.NODE_ENV !== 'production' });
}
function validateConfig({ merchantId, secret, url, allowHttp = false }) {
  if (!uuid.test(merchantId || '') || !text(secret, 4096)) throw new AfihubError('configuration_invalid');
  let endpoint;
  try { endpoint = new URL(url); } catch { throw new AfihubError('endpoint_invalid'); }
  if (!['https:', ...(allowHttp ? ['http:'] : [])].includes(endpoint.protocol) || endpoint.username || endpoint.password || endpoint.search || endpoint.hash || !endpoint.pathname.endsWith('/webhooks/custom')) throw new AfihubError('endpoint_invalid');
  return Object.freeze({ merchantId, secret, url: endpoint.href, allowHttp });
}
export function createClient(options) {
  const config = validateConfig(options || {});
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  if (typeof fetchImpl !== 'function') throw new AfihubError('fetch_unavailable');
  const timeoutMs = options.timeoutMs ?? 15000;
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) throw new AfihubError('timeout_invalid');
  async function sendOrder(transaction, { status = 'paid', paymentVerified = false } = {}) {
    // The brand verifies its gateway. This flag is an explicit integration contract, not verification by this SDK.
    if (paymentVerified !== true) throw new AfihubError('payment_not_verified');
    if (!events[status]) throw new AfihubError('status_invalid');
    const t = transaction || {};
    const session = t.session_token ?? '';
    if (!text(t.order_id, 128) || typeof session !== 'string' || (session && !/^[a-zA-Z0-9_-]{1,256}$/.test(session)) || !money(t.amount) || t.amount === 0 || (t.currency && t.currency !== 'IDR')) throw new AfihubError('transaction_invalid');
    if (!Array.isArray(t.items) || !t.items.length || t.items.length > 100) throw new AfihubError('items_invalid');
    const keys = new Set();
    const items = t.items.map((item, index) => {
      const key = item.line_item_key ?? `${item.product_id}:${item.variant_id || ''}:${index}`;
      if (!text(item.product_id) || !text(key) || keys.has(key) || !Number.isSafeInteger(item.quantity) || item.quantity < 1 || !money(item.unit_price) || !money(item.gross_amount)) throw new AfihubError('item_invalid');
      keys.add(key);
      if (item.sku !== undefined && !text(item.sku)) throw new AfihubError('sku_invalid');
      return { product_id: item.product_id, sku: item.sku || item.product_id, line_item_key: key,
        ...(item.variant_id ? { variant_id: item.variant_id } : {}), quantity: item.quantity, unit_price: item.unit_price, gross_amount: item.gross_amount };
    });
    if (items.reduce((sum, item) => sum + item.gross_amount, 0) !== t.amount) throw new AfihubError('items_amount_mismatch');
    const timestamp = String(Math.floor(Date.now() / 1000));
    const payload = { event: events[status], status, merchant_id: config.merchantId, order_id: t.order_id,
      session_token: session, amount: t.amount, currency: 'IDR', timestamp, items };
    for (const name of ['customer_fingerprint', 'customer_ip', 'customer_user_agent']) {
      if (typeof t[name] === 'string') payload[name] = t[name].slice(0, 512);
    }
    const body = JSON.stringify(payload);
    const signature = createHmac('sha256', config.secret).update(body).digest('hex');
    let response;
    try {
      response = await fetchImpl(config.url, { method: 'POST', body, signal: AbortSignal.timeout(timeoutMs),
        headers: { 'Content-Type': 'application/json', 'X-AfiHub-Timestamp': timestamp, 'X-AfiHub-Signature': 'sha256=' + signature } });
    } catch { throw new AfihubError('network_error', { retryable: true }); }
    if (!response.ok) throw new AfihubError('http_' + response.status, { httpStatus: response.status, retryable: response.status >= 500 || [408, 429].includes(response.status) });
    let result;
    try { result = await response.json(); } catch { throw new AfihubError('response_invalid', { retryable: true }); }
    if (result?.success !== true || !text(result.data?.status)) throw new AfihubError('response_invalid', { retryable: true });
    return result.data;
  }
  return Object.freeze({ sendOrder, version: '0.1.0' });
}
