export interface Config { merchantId: string; secret: string; url: string; allowHttp?: boolean; }
export interface Item { product_id: string; sku?: string; variant_id?: string; line_item_key?: string; quantity: number; unit_price: number; gross_amount: number; }
export interface Transaction { order_id: string; session_token?: string; amount: number; currency?: 'IDR'; items: Item[]; customer_fingerprint?: string; customer_ip?: string; customer_user_agent?: string; }
export type OrderStatus = 'paid' | 'fulfilled' | 'completed' | 'refunded' | 'cancelled';
export class AfihubError extends Error { code: string; httpStatus: number; retryable: boolean; }
export function configFromEnv(env?: Record<string, string | undefined>): Config | null;
export function createClient(options: Config & { fetchImpl?: typeof fetch; timeoutMs?: number }): { sendOrder(transaction: Transaction, options: { status?: OrderStatus; paymentVerified: boolean }): Promise<{ status: string; conversion_id?: string; [key: string]: unknown }>; readonly version: string; };
