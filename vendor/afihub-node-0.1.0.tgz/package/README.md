# @afihub/node 0.1.0

Node >=20, ESM. Paket lokal tersedia melalui Brand Portal; belum dipublikasikan ke registry.

```js
import { createClient, configFromEnv } from '@afihub/node';
const config = configFromEnv(); // load backend .env with your runtime first
const client = config ? createClient(config) : null;
const result = await client.sendOrder(transactionFromDatabase, {
  status: 'paid', paymentVerified: true,
});
```

Config: AFIHUB_MERCHANT_ID, AFIHUB_WEBHOOK_SECRET, AFIHUB_CONVERSION_URL (complete /api/v1/webhooks/custom endpoint). All absent returns null; partial/invalid config throws without exposing values. Production requires HTTPS. paymentVerified is a contract with the caller: SDK cannot verify your gateway. Only set true after verification and persisting payment status.

transaction: order_id, session_token (empty for organic), amount (integer IDR subtotal after discounts without shipping/tax), items (product_id, sku, stable unique line_item_key, quantity, unit_price, gross_amount). Sum gross_amount must equal amount. Product IDs/SKUs must match the Afihub catalog. Status: paid, fulfilled, completed, refunded, cancelled. Returns server data including business status; received is not proof of affiliate commission.

Persist an outbox with order transitions; worker calls sendOrder once per attempt and acknowledges only after success. AfihubError exposes code, httpStatus, retryable without secrets/customer responses. Retry network, 408, 429 and 5xx with backoff/new signature; other 4xx require a fix. Keep order IDs/item keys and status order stable across restarts. Do not fail a verified customer payment because Afihub delivery failed.
