const uuid = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const validClick = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,256}$/.test(value);

/** Browser-only attribution. This library never contains a merchant secret. */
export function createTracker({ merchantId, attributionDays = 7 } = {}) {
  if (!uuid.test(merchantId || '')) throw new TypeError('merchantId must be a merchant UUID.');
  if (!Number.isInteger(attributionDays) || attributionDays < 1 || attributionDays > 90) throw new TypeError('attributionDays must be 1..90.');
  const storageKey = 'afihub:' + merchantId.toLowerCase();
  const browser = () => typeof window === 'undefined' ? null : window;
  function capture() {
    try {
      const target = browser();
      if (!target) return false;
      const value = new URLSearchParams(target.location.search).get('afihub_click_id');
      if (!validClick(value)) return false;
      target.localStorage.setItem(storageKey, JSON.stringify({ value, expires: Date.now() + attributionDays * 86400000 }));
      return true;
    } catch { return false; }
  }
  function getClickId() {
    try {
      const target = browser();
      if (!target) return '';
      const saved = JSON.parse(target.localStorage.getItem(storageKey) || 'null');
      if (validClick(saved?.value) && Number.isFinite(saved.expires) && saved.expires > Date.now()) return saved.value;
      target.localStorage.removeItem(storageKey);
    } catch { /* Storage/consent failures never block shopping. */ }
    return '';
  }
  function clear() { try { browser()?.localStorage.removeItem(storageKey); } catch {} }
  return Object.freeze({ capture, getClickId, clear, storageKey, version: '0.1.0' });
}
