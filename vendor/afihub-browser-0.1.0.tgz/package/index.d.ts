export interface Tracker { capture(): boolean; getClickId(): string; clear(): void; readonly storageKey: string; readonly version: string; }
export function createTracker(options: { merchantId: string; attributionDays?: number }): Tracker;
